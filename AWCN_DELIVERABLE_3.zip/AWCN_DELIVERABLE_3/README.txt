1. Compile all the .c file using "gcc -o filename filename.c" and in case of bluetooth libraries append "-ilbluetooth".
2. Run using "sudo ./filename"
3. For Single fragmentation/defragmentation use folder B-BW-W-W and in that run in the following sequence
	"bt_client1.c -> bt_wi_server.c -> wi_server1.c -> wi_client2.c"
4. For mulitple fragmentation/defragmentation use folder B-BW-WZ-Z and in that run in the following sequence
	"bt_client1.c -> bt_wi_server.c -> wi_zb_server.c -> zb_client.c"
