#include <errno.h>
#include <fcntl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include<netinet/udp.h>   //Provides declarations for udp header
#include<netinet/ip.h>    //Provides declarations for ip header

#define DELIMITER	0x7e
#define FRAMESIZE	8

#define HELLO_LENGTH 	3000
#define MAXLENGTH 	HELLO_LENGTH+20

/*set up serial interface for transmission through xbee module*/
int set_interface_attribs(int fd, int speed)
{
    struct termios tty;

    if (tcgetattr(fd, &tty) < 0) {
        printf("Error from tcgetattr: %s\n", strerror(errno));
        return -1;
    }

    cfsetospeed(&tty, (speed_t)speed);
    cfsetispeed(&tty, (speed_t)speed);

    tty.c_cflag |= (CLOCAL | CREAD);    /* ignore modem controls */
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;         /* 8-bit characters */
    tty.c_cflag &= ~PARENB;     /* no parity bit */
    tty.c_cflag &= ~CSTOPB;     /* only need 1 stop bit */
    tty.c_cflag &= ~CRTSCTS;    /* no hardware flowcontrol */

    /* setup for non-canonical mode */
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tty.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    tty.c_oflag &= ~OPOST;

    /* fetch bytes as they become available */
    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 2;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        printf("Error from tcsetattr: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

int main()
{
    char *portname = "/dev/ttyUSB0";
    int fd;
    int wlen;

    fd = open(portname, O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0) {
        printf("Error opening %s: %s\n", portname, strerror(errno));
        return -1;
    }
    /*baudrate 115200, 8 bits, no parity, 1 stop bit */
    set_interface_attribs(fd, B9600);

    /* simple output */
    wlen = write(fd, "Hello!\n", 7);
    if (wlen != 7) {
        printf("Error from write: %d, %d\n", wlen, errno);
    }
    tcdrain(fd);    /* delay for output */
        int rdlen;
        unsigned char buf[MAXLENGTH];
	unsigned char prevbuf[MAXLENGTH];
	int prevbufLen=0;
	int bufEnd=0;
	rdlen = read(fd, buf, sizeof(buf) - 1);
	int expectedByteCount=0;
	int receivedByteCount=0;
	int packetCount=0;
    do {
	rdlen=0;

	{
		//printf("abt to read");
		rdlen = read(fd, buf, sizeof(buf) - 1);
		if (rdlen > 0) 
		{
		    for(int i=0;i<rdlen;i++)
		    {
			prevbuf[prevbufLen]=buf[i];
		    	prevbufLen++;
			if(buf[i]==DELIMITER && prevbufLen>40)
			{
			    printf("\nend received prevbufLen=%d\n",prevbufLen);
			    //process received data
				unsigned char ipbuf[MAXLENGTH];
			
				
				packetCount++;
				if(packetCount<=10)
					expectedByteCount+=HELLO_LENGTH+5;
				else
					expectedByteCount+=HELLO_LENGTH+6;
				receivedByteCount+=prevbufLen-2;
				for(int j=0;j<prevbufLen;j++)
				{
				    printf("%c",prevbuf[j]);
				}
				printf("\nexpectedByteCount=%d, receivedByteCount=%d, packetCount=%d\n",receivedByteCount,expectedByteCount, packetCount);
				prevbufLen=0;

			}
		    }
			//printf("\n");
		    }

		
	}
        
	    } while (1);
}



