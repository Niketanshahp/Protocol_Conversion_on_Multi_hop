#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/l2cap.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
#include <math.h>
#include <sys/time.h>

#define PORT     8080
#define HELLO_LENGTH 	3000
#define MAXLINE 3000
#define Blue_MTU 256

struct  timeval;
int set_flush_timeout(bdaddr_t *ba, int timeout)
{
    int err = 0, dd;
    struct hci_conn_info_req *cr = 0;
    struct hci_request rq = { 0 };

    struct
    {
        uint16_t handle;
        uint16_t flush_timeout;
    } cmd_param;

    struct
    {
        uint8_t  status;
        uint16_t handle;
    } cmd_response;

    // find the connection handle to the specified bluetooth device
    cr = (struct hci_conn_info_req*) malloc(
            sizeof(struct hci_conn_info_req) +
            sizeof(struct hci_conn_info));
    bacpy( &cr->bdaddr, ba );
    cr->type = ACL_LINK;
    dd = hci_open_dev( hci_get_route( &cr->bdaddr ) );
    if( dd < 0 )
    {
        err = dd;
        goto cleanup;
    }
    err = ioctl(dd, HCIGETCONNINFO, (unsigned long) cr );
    if( err ) goto cleanup;

    // build a command packet to send to the bluetooth microcontroller
    cmd_param.handle = cr->conn_info->handle;
    cmd_param.flush_timeout = htobs(timeout);
    rq.ogf = OGF_HOST_CTL;
    rq.ocf = 0x28;
    rq.cparam = &cmd_param;
    rq.clen = sizeof(cmd_param);
    rq.rparam = &cmd_response;
    rq.rlen = sizeof(cmd_response);
    rq.event = EVT_CMD_COMPLETE;

    // send the command and wait for the response
    err = hci_send_req( dd, &rq, 0 );
    if( err ) goto cleanup;
    printf("Command Response :   %d\n",cmd_response.status);
    if( cmd_response.status )
    {
        err = -1;
        errno = bt_error(cmd_response.status);
    }

cleanup:
    free(cr);
    if( dd >= 0) close(dd);
    return err;
}

struct l2cap_opt
{
    uint16_t    omtu;
    uint16_t    imtu;
    uint16_t    flush_to;
    uint8_t     mode;
};

int set_l2cap_mtu( int sock, uint16_t mtu )
{
    struct l2cap_opt opts; 
    int optlen = sizeof(opts), err;
    err = getsockopt(sock, SOL_L2CAP, L2CAP_OPTIONS, &opts, &optlen );
    if( ! err )
    {
        opts.omtu = opts.imtu = mtu;
        err = setsockopt(sock, SOL_L2CAP, L2CAP_OPTIONS, &opts, optlen );
    }
    return err;
}

long int timeDifference(struct timeval *endTime,struct timeval *startTime)
{
    return (endTime->tv_sec * 1000000 + endTime->tv_usec)
              - (startTime->tv_sec * 1000000 + startTime->tv_usec);
}

int main() 
{
    struct timeval *tv1;
     struct timeval *tv2;
    tv1=(struct timeval*)calloc(1,sizeof(struct timeval));
    tv2=(struct timeval*)calloc(1,sizeof(struct timeval));
    int sockfd,i=0,fragment;
    char buffer[100][MAXLINE] = { 0 };
    char tmpbuff[100][Blue_MTU] = { 0 };
    char buffer2[MAXLINE] = { 0 };

    fragment = ceil(MAXLINE / Blue_MTU) + 1;
//    struct sockaddr_in servaddr, cliaddr1;
    struct sockaddr_l2 loc_addr = { 0 }, rem_addr = { 0 };
    char buf[MAXLINE]  = { 0 };
    int s, client, bytes_read,cap_stat,status,temp;
    socklen_t opt = sizeof(rem_addr);


//    unsigned char hello[HELLO_LENGTH];



    if ((s = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP)) < 0)
    {
        perror("blue_socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&loc_addr, 0, sizeof(loc_addr));
    memset(&rem_addr, 0, sizeof(rem_addr));

    loc_addr.l2_family = AF_BLUETOOTH;
    loc_addr.l2_bdaddr = *BDADDR_ANY;
    loc_addr.l2_psm = htobs(0x1001);

    if( bind(s, (struct sockaddr *)&loc_addr, sizeof(loc_addr)) < 0)
    {
        perror("blue_bind failed");
        exit(EXIT_FAILURE);
    }
    printf("BL sock binded\n");
 
    cap_stat = set_l2cap_mtu(s,Blue_MTU);
    listen(s, 1);
    printf("Listen\n");
    client = accept(s, (struct sockaddr *)&rem_addr, &opt);
    printf("ACCEPT : %d\n",client);

    temp = set_flush_timeout(&rem_addr.l2_bdaddr , 1);
    if(temp < 0)
    {
    perror("unrelaible socket cleaned up \n");
    }

    ba2str( &rem_addr.l2_bdaddr, buf );
    fprintf(stderr, "accepted connection from %s\n", buf);
    cap_stat = set_l2cap_mtu(client,Blue_MTU);    

    memset(buf, 0, sizeof(buf));
    bytes_read = read(client, buf, sizeof(buf));
    if( bytes_read > 0 )
    {
        printf("received [%s]\n", buf);
    }

    int cli1len, n, m ;
//    cli1len = sizeof(cliaddr1); 
    int bytes;
    

    unsigned char val=0x30;
    char hello[HELLO_LENGTH];
    int j;
    for(j=0;j<HELLO_LENGTH-1;j++)
   {
      hello[j]=val;
      val++;
      if(val==0x3a)
      val=0x41;
      else if(val==0x5b)
      val=0x61;
      else if(val==0x7b)
      val=0x30;
    }
    hello[j]='\0'; 

    for(i=0;i<100;i++)
    { 
    int ret;
    if(i==0)
	ret=gettimeofday(tv1, NULL);
    if(ret!=0)
	printf("error in gettimeofday");
    printf("Start time in us : %ld   %ld",tv1->tv_sec ,tv1->tv_usec);
    int k,l;
    for(k=0;k<fragment;k++)
    {
    for(l=0;l<Blue_MTU-1;l++)
    {
     tmpbuff[k][l] = hello[(k * Blue_MTU)+l];
    }
//    tmpbuff[k][l] = '\0';
    printf("Fragment Buffer : %d : %s \n",k,tmpbuff[k]);
    status = write(client, (char *)tmpbuff[k], Blue_MTU);
    if( status < 0 ) 
    {
    perror("Unable to write to client2");
    }
    else
    {
    printf("successfully written %d times to client2\n",i);
    int ret1=gettimeofday(tv2, NULL);
    if(ret1!=0)
	printf("error in gettimeofday");
    printf("End time in us : %ld  %ld\n",tv2->tv_sec ,tv2->tv_usec);
    } 
    }
    }
//    close(sockfd);
    close(s);
    return 0;
}
