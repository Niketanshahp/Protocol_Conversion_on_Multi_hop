#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
 
#define PORT     8080
#define MAXLINE 900
 


int main() 
{
    
    int sockfd,i=0;
    char buffer[100][MAXLINE];
    char buffer2[MAXLINE];
    char *hello = "Hello from server";
    struct sockaddr_in servaddr, cliaddr1;
     
    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
     
    memset(&servaddr, 0, sizeof(servaddr));
    memset(&cliaddr1, 0, sizeof(cliaddr1));
    

     
    // Filling server information
    servaddr.sin_family    = AF_INET; // IPv4
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);
     
    // Bind the socket with the server address
    if ( bind(sockfd, (const struct sockaddr *)&servaddr, 
            sizeof(servaddr)) < 0 )
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
     
    int cli1len, cli2len, n, m ;
    
    cli1len = sizeof(cliaddr1); 
    // m = recvfrom(sockfd, (char *)buffer2, MAXLINE,
    //             MSG_WAITALL, ( struct sockaddr *) &cliaddr2,
    
    int bytes,count=0;
    for(i=0;i<100;i++)
    { 
    n = recvfrom(sockfd, (char *)buffer[i], MAXLINE, 
                MSG_WAITALL, ( struct sockaddr *) &cliaddr1,
                &cli1len);
    buffer[i][n] = '\0';  
    printf("Server2 : %s\n %d Number of  times", buffer[i],count);
    count++;
    }
    return 0;
}
