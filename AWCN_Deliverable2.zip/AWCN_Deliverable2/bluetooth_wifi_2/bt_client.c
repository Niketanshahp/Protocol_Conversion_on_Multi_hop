#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/l2cap.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
#include <math.h>
#include <sys/time.h>

#define Blue_MTU 256
#define MAXLINE 915


int set_flush_timeout(bdaddr_t *ba, int timeout)
{
    int err = 0, dd;
    struct hci_conn_info_req *cr = 0;
    struct hci_request rq = { 0 };

    struct
    {
        uint16_t handle;
        uint16_t flush_timeout;
    } cmd_param;

    struct
    {
        uint8_t  status;
        uint16_t handle;
    } cmd_response;

    // find the connection handle to the specified bluetooth device
    cr = (struct hci_conn_info_req*) malloc(
            sizeof(struct hci_conn_info_req) +
            sizeof(struct hci_conn_info));
    bacpy( &cr->bdaddr, ba );
    cr->type = ACL_LINK;
    dd = hci_open_dev( hci_get_route( &cr->bdaddr ) );
    if( dd < 0 )
    {
        err = dd;
        goto cleanup;
    }
    err = ioctl(dd, HCIGETCONNINFO, (unsigned long) cr );
    if( err ) goto cleanup;

    // build a command packet to send to the bluetooth microcontroller
    cmd_param.handle = cr->conn_info->handle;
    cmd_param.flush_timeout = htobs(timeout);
    rq.ogf = OGF_HOST_CTL;
    rq.ocf = 0x28;
    rq.cparam = &cmd_param;
    rq.clen = sizeof(cmd_param);
    rq.rparam = &cmd_response;
    rq.rlen = sizeof(cmd_response);
    rq.event = EVT_CMD_COMPLETE;

    // send the command and wait for the response
    err = hci_send_req( dd, &rq, 0 );
    if( err ) goto cleanup;
    
    printf("Command Response:   %d\n",cmd_response.status);

   
    if( cmd_response.status )
    {
        err = -1;
        errno = bt_error(cmd_response.status);
    }

cleanup:
    free(cr);
    if( dd >= 0) close(dd);
    return err;
}



struct l2cap_opt
{
    uint16_t    omtu;
    uint16_t    imtu;
    uint16_t    flush_to;
    uint8_t     mode;
};

int set_l2cap_mtu( int sock, uint16_t mtu )
{
    struct l2cap_opt opts; 
    int optlen = sizeof(opts), err;
    err = getsockopt(sock, SOL_L2CAP, L2CAP_OPTIONS, &opts, &optlen );
    if( ! err )
    {
        opts.omtu = opts.imtu = mtu;
        err = setsockopt(sock, SOL_L2CAP, L2CAP_OPTIONS, &opts, optlen );
    }
    return err;
}

int main() 
{
    struct timeval *tv1,*tv2;
    tv1=(struct timeval*)malloc(sizeof(struct timeval));
    tv2=(struct timeval*)malloc(sizeof(struct timeval));
    struct sockaddr_l2 addr = { 0 },local = {0};
    int s, status,cap_stat,byte_wr,temp,bytes_read,i,fragment;
    char *message = "hello from client2";
    char dest[18] = "80:C5:F2:B7:02:BC";  //asus
//rpi    char dest[18] = "B8:27:EB:9C:D3:58";
    fragment = ceil(MAXLINE / Blue_MTU);
    if((s = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP)) < 0)
    {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    local.l2_family = AF_BLUETOOTH;
    local.l2_cid = htobs(0x0002);
    local.l2_bdaddr = *BDADDR_ANY;


    addr.l2_family = AF_BLUETOOTH;
    addr.l2_psm = htobs(0x1001);
    str2ba( dest, &addr.l2_bdaddr );

   

    cap_stat = set_l2cap_mtu(s,Blue_MTU);

    status = connect(s, (struct sockaddr *)&addr, sizeof(addr));
     
    temp = set_flush_timeout(&addr.l2_bdaddr, 1);
    if(temp < 0)
    {
    perror("unrelaible socket cleaned up \n");
    }



    if( status == 0 ) 
    {
        byte_wr = write(s, "hello from client2", 18);
    }
    if( byte_wr < 0 ) 
    {
    perror("Unable to write from client1");
    }
    else
    {
    
    printf("Hello message sent to server.\n");
    }
    int pck_cnt = 0;
    do
    {
    char buffer[Blue_MTU+10] = { 0 };
    printf("\nread start at:");
    gettimeofday(tv1, NULL);
    printf("%ldmicroseconds",tv1->tv_sec * 1000000 + tv1->tv_usec);   
    bytes_read = read(s, buffer, sizeof(buffer));
    printf("\nread end at:");
    gettimeofday(tv2, NULL);   
    printf("%ldmicroseconds",tv2->tv_sec * 1000000 + tv2->tv_usec);   
    buffer[bytes_read+10] = '\0';
    printf("Server : %s\n", buffer);
    if( bytes_read < 0 )
    {
    perror("Unable to read from server");
    }
    else
    {
    pck_cnt++;
    printf("Hello message read from server: %d times \n",pck_cnt);
    }
    usleep(40000);
    }while(bytes_read > 0);
//    sleep(2);
    close(s);
    return 0;
}
