wifi_4 :
wi_client1(Pi w/o base) -> wi_server1(Asus) -> wi_server2(Pi with base) -> wi_client2(Samsung)

wifi_xbee :
wi_cleint1(pi w/o base) -> wi_server1(Asus) -> wi_zb_server(pi with base) -> zb_client(Samsung)

wifi_bletooth :
wi_client1(samsung) -> wi_server1(pi w/o base) -> wi_bt_server(Asus) -> bt_client(Pi with base) 

wifi_bluetooth_xbee :
wi_client1(pi w/o base) -> wi_bt_server(Asus) -> bt_zb_server(pi with base) -> zb_client(samsung) 
